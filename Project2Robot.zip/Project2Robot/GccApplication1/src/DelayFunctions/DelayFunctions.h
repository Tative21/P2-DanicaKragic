//
//  DelayFunctions.h
//
//  Ulrik Eklund 2014
//
//


#ifndef DelayFunctions_h
#define DelayFunctions_h

int delayInit(void);
void delayMicroseconds(uint32_t us);
#endif
