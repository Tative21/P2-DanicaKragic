/*
 * PWMfunctions.h
 *
 * Created: 2016-04-10 13:38:54
 *  Author: Martin
 */ 


#ifndef PWMFUNCTIONS_H_
#define PWMFUNCTIONS_H_


void InitPWM(void);


#endif /* PWMFUNCTIONS_H_ */