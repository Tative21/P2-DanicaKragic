/*
 * TaskJoystick.h
 *
 * Created: 2016-04-10 13:35:33
 *  Author: Michael och Martin
 */ 


#ifndef TASKJOYSTICK_H_
#define TASKJOYSTICK_H_
#define LED PIO_PC21_IDX

void TaskJoystick(void *p);



#endif /* TASKJOYSTICK_H_ */