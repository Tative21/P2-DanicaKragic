/*
 * JoystickOptionsYAxis.c
 *
 * Created: 2016-04-18 14:58:47
 *  Author: Spellabbet
 */ 

#include <asf.h>
#include <inttypes.h>
#include "adc/adcFunctions.h"
#include "Tasks/TaskDriveForward.h"
#include "DriveOptions/driveForward.h"

static uint32_t sampleTime = 150;

void TaskOptionsYAxis(void *p)
{
	uint32_t joystick_y;
	
	
	/*pinMode(Analog0,Input);	//x-axeln till joysticken									Analog In 0
	pinMode(Analog1,Input);	//y-axeln till joysticken									Analog In 1
	
	pinMode(pin3,Output);	// digital pin f�r lampa									Digital Pin 3
	pinMode(pin8,Output);	// digital pin f�r lampa									Digital pin 8
	pinMode(pin6,Output);// D� man trycker p� joysticken ska en lampa lyssna			Digital pin 6
	pinMode(pin5,Input); //L�ser av switchen p� joysticken(trycker p� joysticken)		Digital Pin 5
	pinMode(pin11,Output);*/
	
	portTickType xLastWakeTime;
	portTickType xSampleTime;
	xLastWakeTime = xTaskGetTickCount();
	
	while(1){
	
		xSampleTime = (portTickType)sampleTime;
		vTaskDelayUntil(&xLastWakeTime, xSampleTime);
		joystick_y = ReadAnalog1();
		
		if((joystick_y > 585)) // k�r fram
		{
			Forward_100();
		}
		if((joystick_y <= 585)) // K�r bak
		{
			Forward_50();
		}
	}
	
}