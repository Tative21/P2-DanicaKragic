/*
 * Styrning.h
 *
 * Created: 2016-04-18 13:59:28
 *  Author: Michael och Martin
 */ 


#ifndef STYRNING_H_
#define STYRNING_H_
#define pin9 PIO_PC21_IDX

void Right_15Degrees(void);
void Right_30Degrees(void);
void Right_45Degrees(void);
void Right_60Degrees(void);
void Right_75Degrees(void);
void Right_90Degrees(void);


#endif /* STYRNING_H_ */