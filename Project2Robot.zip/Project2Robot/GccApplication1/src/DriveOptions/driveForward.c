/*
 * driveForward.c
 *
 * Created: 2016-04-19 12:46:04
 *  Author: Michael och Martin
 */ 

#include <asf.h>
#include <inttypes.h>
#include "DelayFunctions/DelayFunctions.h"
#include "DriveOptions/driveForward.h"

/*
******************************************************************************
*
*
******************************************************************************
*/
void standBymode()
{
	ioport_set_pin_level(pin9,HIGH);		// s�tter pin 9 till h�g
	delayMicroseconds(1500);				// v�ntar i 1500 �s
	ioport_set_pin_level(pin9,LOW);			// s�tter pin 9 till l�g
	delayMicroseconds(1150);				// v�ntar i 1150 �s
	ioport_set_pin_level(pin9,HIGH);		// s�tter pin 9 till h�g
	delayMicroseconds(1500);				// v�ntar i 1500 �s
	ioport_set_pin_level(pin9,LOW);			// s�tter pin 9 till l�g
	delayMicroseconds(5350);				// v�ntar i 5350 �s
}

void Forward_50()
{
	ioport_set_pin_level(pin9,HIGH);		// s�tter pin 9 till h�g
	delayMicroseconds(1100);				// v�ntar i 1500 �s
	ioport_set_pin_level(pin9,LOW);			// s�tter pin 9 till l�g
	delayMicroseconds(1150);				// v�ntar i 1150 �s
	ioport_set_pin_level(pin9,HIGH);		// s�tter pin 9 till h�g
	delayMicroseconds(1100);				// v�ntar i 1500 �s
	ioport_set_pin_level(pin9,LOW);			// s�tter pin 9 till l�g
	delayMicroseconds(5350);				// v�ntar i 5350 �s
}

void Forward_100()
{
	ioport_set_pin_level(pin9,HIGH);		// s�tter pin 9 till h�g
	delayMicroseconds(950);				// v�ntar i 1500 �s
	ioport_set_pin_level(pin9,LOW);			// s�tter pin 9 till l�g
	delayMicroseconds(1150);				// v�ntar i 1150 �s
	ioport_set_pin_level(pin9,HIGH);		// s�tter pin 9 till h�g
	delayMicroseconds(950);				// v�ntar i 1500 �s
	ioport_set_pin_level(pin9,LOW);			// s�tter pin 9 till l�g
	delayMicroseconds(5350);				// v�ntar i 5350 �s
}


