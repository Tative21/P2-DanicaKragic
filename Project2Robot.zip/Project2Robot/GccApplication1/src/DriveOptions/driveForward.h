/*
 * driveForward.h
 *
 * Created: 2016-04-19 12:46:16
 *  Author: Michael och Martin
 */ 


#ifndef DRIVEFORWARD_H_
#define DRIVEFORWARD_H_
#define pin9 PIO_PC21_IDX

void standBymode(void);
void Forward_50(void);
void Forward_100(void);



#endif /* DRIVEFORWARD_H_ */