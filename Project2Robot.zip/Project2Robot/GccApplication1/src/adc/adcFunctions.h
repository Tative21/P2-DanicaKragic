/*
 * adcFunctions.h
 *
 * Created: 2016-04-10 13:01:19
 *  Author: Martin
 */ 


#ifndef ADCFUNCTIONS_H_
#define ADCFUNCTIONS_H_


int analogInit(void);
uint32_t ReadAnalog(void);


#endif /* ADCFUNCTIONS_H_ */