/*
 * adcFunctions.h
 *
 * Created: 2016-04-10 13:01:19
 *  Author: Martin William Elvin
 */ 


#ifndef ADCFUNCTIONS_H_
#define ADCFUNCTIONS_H_


int analogInit(void);
uint32_t ReadAnalog0(void);
uint32_t ReadAnalog1(void);
uint32_t ReadAnalog2(void);


#endif /* ADCFUNCTIONS_H_ */