/*
 * adcFunctions.c
 *
 * Created: 2016-04-10 13:00:57
 *  Author: Martin
 */ 

#include <inttypes.h>
#include <asf.h>
#include "adcFunctions.h"


int analogInit(void)
{
	pmc_enable_periph_clk(ID_ADC);
	adc_init(ADC,sysclk_get_main_hz(),1000000,8);
	adc_configure_timing(ADC,0,ADC_SETTLING_TIME_3,1);
	adc_set_resolution(ADC,ADC_MR_LOWRES_BITS_10);
	adc_enable_channel(ADC,ADC_CHANNEL_7);
	adc_configure_trigger(ADC,ADC_TRIG_SW,0);
}

uint32_t ReadAnalog(void)
{
	uint32_t currentjoystickvalue;
	adc_start(ADC);
	currentjoystickvalue = adc_get_channel_value(ADC,ADC_CHANNEL_7);
	
	return currentjoystickvalue;
}

